-- Audit every balance change automatically
CREATE OR REPLACE TRIGGER trg_accounts_audit
AFTER UPDATE OF balance ON accounts
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (account_id, old_balance, new_balance)
    VALUES (:OLD.account_id, :OLD.balance, :NEW.balance);
END;
/
