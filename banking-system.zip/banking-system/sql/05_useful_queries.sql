-- Mini statement: last 10 transactions for an account
SELECT txn_id, txn_type, amount, balance_after, txn_time
  FROM bank_transactions
 WHERE account_id = 1
 ORDER BY txn_time DESC
 FETCH FIRST 10 ROWS ONLY;

-- Total deposited and withdrawn per account (join + group by)
SELECT a.account_id, a.holder_name,
       SUM(CASE WHEN t.txn_type = 'DEPOSIT'  THEN t.amount ELSE 0 END) AS total_deposits,
       SUM(CASE WHEN t.txn_type = 'WITHDRAW' THEN t.amount ELSE 0 END) AS total_withdrawals
  FROM accounts a
  LEFT JOIN bank_transactions t ON t.account_id = a.account_id
 GROUP BY a.account_id, a.holder_name;

-- Rank accounts by balance (window function)
SELECT account_id, holder_name, balance,
       RANK() OVER (ORDER BY balance DESC) AS balance_rank
  FROM accounts;

-- Audit trail
SELECT * FROM audit_log ORDER BY changed_at DESC;
