-- Run as the application user (e.g. BANKUSER)

CREATE TABLE accounts (
    account_id   NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    holder_name  VARCHAR2(100) NOT NULL,
    balance      NUMBER(15,2) DEFAULT 0 NOT NULL,
    created_at   TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT chk_balance_nonneg CHECK (balance >= 0)
);

CREATE TABLE bank_transactions (
    txn_id             NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    account_id         NUMBER NOT NULL,
    txn_type           VARCHAR2(20) NOT NULL,
    amount             NUMBER(15,2) NOT NULL,
    balance_after      NUMBER(15,2) NOT NULL,
    related_account_id NUMBER,
    txn_time           TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT fk_txn_account FOREIGN KEY (account_id) REFERENCES accounts(account_id),
    CONSTRAINT chk_txn_type CHECK (txn_type IN ('DEPOSIT','WITHDRAW','TRANSFER_OUT','TRANSFER_IN')),
    CONSTRAINT chk_txn_amount CHECK (amount > 0)
);

CREATE TABLE audit_log (
    audit_id     NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    account_id   NUMBER NOT NULL,
    old_balance  NUMBER(15,2),
    new_balance  NUMBER(15,2),
    changed_by   VARCHAR2(50) DEFAULT USER,
    changed_at   TIMESTAMP DEFAULT SYSTIMESTAMP
);

CREATE INDEX idx_txn_account_time ON bank_transactions(account_id, txn_time DESC);
