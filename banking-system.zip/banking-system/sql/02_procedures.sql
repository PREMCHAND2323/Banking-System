-- Each procedure commits on success and rolls back on any error (atomic transactions).
-- Custom error codes: -20001 insufficient funds, -20002 account not found,
--                     -20003 invalid amount,     -20004 same-account transfer

CREATE OR REPLACE PROCEDURE sp_deposit (
    p_account_id IN NUMBER,
    p_amount     IN NUMBER
) AS
    v_balance NUMBER;
BEGIN
    IF p_amount IS NULL OR p_amount <= 0 THEN
        RAISE_APPLICATION_ERROR(-20003, 'Amount must be greater than zero');
    END IF;

    SELECT balance INTO v_balance FROM accounts WHERE account_id = p_account_id FOR UPDATE;

    UPDATE accounts SET balance = balance + p_amount WHERE account_id = p_account_id;

    INSERT INTO bank_transactions (account_id, txn_type, amount, balance_after)
    VALUES (p_account_id, 'DEPOSIT', p_amount, v_balance + p_amount);

    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20002, 'Account not found');
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END sp_deposit;
/

CREATE OR REPLACE PROCEDURE sp_withdraw (
    p_account_id IN NUMBER,
    p_amount     IN NUMBER
) AS
    v_balance NUMBER;
BEGIN
    IF p_amount IS NULL OR p_amount <= 0 THEN
        RAISE_APPLICATION_ERROR(-20003, 'Amount must be greater than zero');
    END IF;

    SELECT balance INTO v_balance FROM accounts WHERE account_id = p_account_id FOR UPDATE;

    IF v_balance < p_amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds');
    END IF;

    UPDATE accounts SET balance = balance - p_amount WHERE account_id = p_account_id;

    INSERT INTO bank_transactions (account_id, txn_type, amount, balance_after)
    VALUES (p_account_id, 'WITHDRAW', p_amount, v_balance - p_amount);

    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20002, 'Account not found');
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END sp_withdraw;
/

CREATE OR REPLACE PROCEDURE sp_transfer (
    p_from_account IN NUMBER,
    p_to_account   IN NUMBER,
    p_amount       IN NUMBER
) AS
    v_from_balance NUMBER;
    v_to_balance   NUMBER;
BEGIN
    IF p_amount IS NULL OR p_amount <= 0 THEN
        RAISE_APPLICATION_ERROR(-20003, 'Amount must be greater than zero');
    END IF;
    IF p_from_account = p_to_account THEN
        RAISE_APPLICATION_ERROR(-20004, 'Cannot transfer to the same account');
    END IF;

    -- Lock both rows in a fixed (id) order so two opposite transfers cannot deadlock
    FOR r IN (SELECT account_id, balance
                FROM accounts
               WHERE account_id IN (p_from_account, p_to_account)
               ORDER BY account_id
                 FOR UPDATE) LOOP
        IF r.account_id = p_from_account THEN
            v_from_balance := r.balance;
        ELSE
            v_to_balance := r.balance;
        END IF;
    END LOOP;

    IF v_from_balance IS NULL OR v_to_balance IS NULL THEN
        RAISE_APPLICATION_ERROR(-20002, 'Account not found');
    END IF;
    IF v_from_balance < p_amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds');
    END IF;

    UPDATE accounts SET balance = balance - p_amount WHERE account_id = p_from_account;
    UPDATE accounts SET balance = balance + p_amount WHERE account_id = p_to_account;

    INSERT INTO bank_transactions (account_id, txn_type, amount, balance_after, related_account_id)
    VALUES (p_from_account, 'TRANSFER_OUT', p_amount, v_from_balance - p_amount, p_to_account);

    INSERT INTO bank_transactions (account_id, txn_type, amount, balance_after, related_account_id)
    VALUES (p_to_account, 'TRANSFER_IN', p_amount, v_to_balance + p_amount, p_from_account);

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END sp_transfer;
/
