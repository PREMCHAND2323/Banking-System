INSERT INTO accounts (holder_name, balance) VALUES ('Alice', 5000);
INSERT INTO accounts (holder_name, balance) VALUES ('Bob', 2500);
COMMIT;
