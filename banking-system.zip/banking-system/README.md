# Banking / Transaction Management System

A REST API for basic banking operations where the **business logic lives in Oracle PL/SQL stored procedures**
and is exposed through a Spring Boot + JDBC application.

## Features
- Create accounts, deposit, withdraw, and transfer between accounts
- PL/SQL procedures (`sp_deposit`, `sp_withdraw`, `sp_transfer`) with commit/rollback for atomic transactions
- Row locking (`SELECT ... FOR UPDATE`) in a fixed order to prevent lost updates and deadlocks
- Database trigger (`trg_accounts_audit`) that writes every balance change to an `audit_log` table
- Constraints (`CHECK balance >= 0`, foreign keys) to protect data integrity
- Transaction history per account (mini statement)
- Custom Oracle error codes (ORA-20001 to ORA-20004) translated to proper HTTP responses
- Input validation and unit tests (JUnit 5 + Mockito)

## Tech stack
Java 17, Spring Boot 3, Spring JDBC (JdbcTemplate / SimpleJdbcCall), Oracle Database (PL/SQL), Maven, JUnit 5, Mockito

## Project structure
```
sql/                    Schema, PL/SQL procedures, trigger, sample data, useful queries
src/main/java/...       controller, service, repository, model, dto, exception
src/test/java/...       service-layer unit tests
```

## Setup

### 1. Start Oracle (Docker)
```bash
docker run -d --name oracle-xe -p 1521:1521 \
  -e ORACLE_PASSWORD=admin123 \
  -e APP_USER=bankuser -e APP_USER_PASSWORD=bankpass \
  gvenzl/oracle-xe:21-slim
```
(Or use any Oracle 12c+ database and create your own user.)

### 2. Create the database objects
Connect as `bankuser` (SQL Developer, SQLcl, or the VS Code Oracle extension) to
`localhost:1521/XEPDB1` and run, in order:
`sql/01_schema.sql`, `sql/02_procedures.sql`, `sql/03_triggers.sql`, `sql/04_sample_data.sql`

### 3. Run the application
```bash
mvn spring-boot:run
```
Override the connection with the `DB_URL`, `DB_USER`, and `DB_PASSWORD` environment variables.

### 4. Run tests
```bash
mvn test
```

## API
| Method | Endpoint | Body |
|--------|----------|------|
| POST | `/api/accounts` | `{"holderName":"Ravi","initialDeposit":1000}` |
| GET | `/api/accounts` | |
| GET | `/api/accounts/{id}` | |
| GET | `/api/accounts/{id}/transactions` | |
| POST | `/api/accounts/{id}/deposit` | `{"amount":500}` |
| POST | `/api/accounts/{id}/withdraw` | `{"amount":200}` |
| POST | `/api/transfers` | `{"fromAccountId":1,"toAccountId":2,"amount":300}` |

### Example
```bash
curl -X POST localhost:8080/api/transfers -H "Content-Type: application/json" \
  -d '{"fromAccountId":1,"toAccountId":2,"amount":300}'
```
Overdrawing returns HTTP 422 `{"error":"Insufficient funds"}`.

## Concepts demonstrated
ACID transactions, PL/SQL procedures and exception handling, triggers, row-level locking,
constraints and indexes, window functions (`sql/05_useful_queries.sql`), layered architecture, REST API design.

## Author
Kanyadhari Premchand
