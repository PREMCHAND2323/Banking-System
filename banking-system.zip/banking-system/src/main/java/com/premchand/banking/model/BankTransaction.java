package com.premchand.banking.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record BankTransaction(long txnId, long accountId, String txnType, BigDecimal amount,
                              BigDecimal balanceAfter, Long relatedAccountId, LocalDateTime txnTime) {
}
