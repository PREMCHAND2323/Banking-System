package com.premchand.banking.service;

import com.premchand.banking.exception.BankingException;
import com.premchand.banking.model.Account;
import com.premchand.banking.model.BankTransaction;
import com.premchand.banking.repository.AccountRepository;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class BankingService {

    private final AccountRepository repository;

    public BankingService(AccountRepository repository) {
        this.repository = repository;
    }

    public Account createAccount(String holderName, BigDecimal initialDeposit) {
        long id = repository.createAccount(holderName);
        if (initialDeposit != null && initialDeposit.signum() > 0) {
            deposit(id, initialDeposit);
        }
        return getAccount(id);
    }

    public Account getAccount(long accountId) {
        return repository.findById(accountId)
                .orElseThrow(() -> new BankingException(HttpStatus.NOT_FOUND, "Account not found"));
    }

    public List<Account> getAllAccounts() {
        return repository.findAll();
    }

    public List<BankTransaction> getTransactions(long accountId) {
        getAccount(accountId); // 404 if the account does not exist
        return repository.findTransactions(accountId);
    }

    public Account deposit(long accountId, BigDecimal amount) {
        execute(() -> repository.deposit(accountId, amount));
        return getAccount(accountId);
    }

    public Account withdraw(long accountId, BigDecimal amount) {
        execute(() -> repository.withdraw(accountId, amount));
        return getAccount(accountId);
    }

    public void transfer(long fromAccountId, long toAccountId, BigDecimal amount) {
        execute(() -> repository.transfer(fromAccountId, toAccountId, amount));
    }

    private void execute(Runnable action) {
        try {
            action.run();
        } catch (DataAccessException ex) {
            throw translate(ex);
        }
    }

    /** Converts ORA-200xx errors raised by the PL/SQL procedures into HTTP-friendly exceptions. */
    private RuntimeException translate(DataAccessException ex) {
        Throwable cause = ex;
        while (cause != null) {
            if (cause instanceof SQLException sql) {
                switch (sql.getErrorCode()) {
                    case 20001:
                        return new BankingException(HttpStatus.UNPROCESSABLE_ENTITY, "Insufficient funds");
                    case 20002:
                        return new BankingException(HttpStatus.NOT_FOUND, "Account not found");
                    case 20003:
                        return new BankingException(HttpStatus.BAD_REQUEST, "Amount must be greater than zero");
                    case 20004:
                        return new BankingException(HttpStatus.BAD_REQUEST, "Cannot transfer to the same account");
                    default:
                        break;
                }
            }
            cause = cause.getCause();
        }
        return ex;
    }
}
