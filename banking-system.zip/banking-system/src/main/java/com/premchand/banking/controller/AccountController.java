package com.premchand.banking.controller;

import com.premchand.banking.dto.AmountRequest;
import com.premchand.banking.dto.CreateAccountRequest;
import com.premchand.banking.dto.TransferRequest;
import com.premchand.banking.model.Account;
import com.premchand.banking.model.BankTransaction;
import com.premchand.banking.service.BankingService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class AccountController {

    private final BankingService service;

    public AccountController(BankingService service) {
        this.service = service;
    }

    @PostMapping("/accounts")
    public ResponseEntity<Account> create(@Valid @RequestBody CreateAccountRequest request) {
        Account account = service.createAccount(request.holderName(), request.initialDeposit());
        return ResponseEntity.status(HttpStatus.CREATED).body(account);
    }

    @GetMapping("/accounts")
    public List<Account> list() {
        return service.getAllAccounts();
    }

    @GetMapping("/accounts/{id}")
    public Account get(@PathVariable long id) {
        return service.getAccount(id);
    }

    @GetMapping("/accounts/{id}/transactions")
    public List<BankTransaction> transactions(@PathVariable long id) {
        return service.getTransactions(id);
    }

    @PostMapping("/accounts/{id}/deposit")
    public Account deposit(@PathVariable long id, @Valid @RequestBody AmountRequest request) {
        return service.deposit(id, request.amount());
    }

    @PostMapping("/accounts/{id}/withdraw")
    public Account withdraw(@PathVariable long id, @Valid @RequestBody AmountRequest request) {
        return service.withdraw(id, request.amount());
    }

    @PostMapping("/transfers")
    public Map<String, String> transfer(@Valid @RequestBody TransferRequest request) {
        service.transfer(request.fromAccountId(), request.toAccountId(), request.amount());
        return Map.of("message", "Transfer successful");
    }
}
