package com.premchand.banking.repository;

import com.premchand.banking.model.Account;
import com.premchand.banking.model.BankTransaction;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

/** Data access layer: plain JDBC queries plus calls to the Oracle PL/SQL stored procedures. */
@Repository
public class AccountRepository {

    private final JdbcTemplate jdbc;

    private static final RowMapper<Account> ACCOUNT_MAPPER = (rs, i) -> new Account(
            rs.getLong("account_id"),
            rs.getString("holder_name"),
            rs.getBigDecimal("balance"),
            rs.getTimestamp("created_at").toLocalDateTime());

    private static final RowMapper<BankTransaction> TXN_MAPPER = AccountRepository::mapTxn;

    public AccountRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private static BankTransaction mapTxn(ResultSet rs, int rowNum) throws SQLException {
        long related = rs.getLong("related_account_id");
        Long relatedId = rs.wasNull() ? null : related;
        return new BankTransaction(
                rs.getLong("txn_id"),
                rs.getLong("account_id"),
                rs.getString("txn_type"),
                rs.getBigDecimal("amount"),
                rs.getBigDecimal("balance_after"),
                relatedId,
                rs.getTimestamp("txn_time").toLocalDateTime());
    }

    public long createAccount(String holderName) {
        SimpleJdbcInsert insert = new SimpleJdbcInsert(jdbc)
                .withTableName("accounts")
                .usingColumns("holder_name")
                .usingGeneratedKeyColumns("account_id");
        return insert.executeAndReturnKey(Map.of("holder_name", holderName)).longValue();
    }

    public Optional<Account> findById(long accountId) {
        List<Account> rows = jdbc.query(
                "SELECT account_id, holder_name, balance, created_at FROM accounts WHERE account_id = ?",
                ACCOUNT_MAPPER, accountId);
        return rows.stream().findFirst();
    }

    public List<Account> findAll() {
        return jdbc.query(
                "SELECT account_id, holder_name, balance, created_at FROM accounts ORDER BY account_id",
                ACCOUNT_MAPPER);
    }

    public List<BankTransaction> findTransactions(long accountId) {
        return jdbc.query(
                "SELECT txn_id, account_id, txn_type, amount, balance_after, related_account_id, txn_time "
                        + "FROM bank_transactions WHERE account_id = ? ORDER BY txn_time DESC, txn_id DESC",
                TXN_MAPPER, accountId);
    }

    public void deposit(long accountId, BigDecimal amount) {
        new SimpleJdbcCall(jdbc).withProcedureName("sp_deposit")
                .execute(Map.of("p_account_id", accountId, "p_amount", amount));
    }

    public void withdraw(long accountId, BigDecimal amount) {
        new SimpleJdbcCall(jdbc).withProcedureName("sp_withdraw")
                .execute(Map.of("p_account_id", accountId, "p_amount", amount));
    }

    public void transfer(long fromAccountId, long toAccountId, BigDecimal amount) {
        new SimpleJdbcCall(jdbc).withProcedureName("sp_transfer")
                .execute(Map.of("p_from_account", fromAccountId,
                        "p_to_account", toAccountId,
                        "p_amount", amount));
    }
}
