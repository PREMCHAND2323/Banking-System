package com.premchand.banking.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

public record AmountRequest(@NotNull(message = "amount is required")
                            @Positive(message = "amount must be greater than zero") BigDecimal amount) {
}
