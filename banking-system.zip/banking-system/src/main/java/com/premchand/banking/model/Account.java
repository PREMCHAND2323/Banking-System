package com.premchand.banking.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record Account(long accountId, String holderName, BigDecimal balance, LocalDateTime createdAt) {
}
