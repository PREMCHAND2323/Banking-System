package com.premchand.banking.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;

public record CreateAccountRequest(@NotBlank(message = "holderName is required") String holderName,
                                   @PositiveOrZero(message = "initialDeposit cannot be negative") BigDecimal initialDeposit) {
}
