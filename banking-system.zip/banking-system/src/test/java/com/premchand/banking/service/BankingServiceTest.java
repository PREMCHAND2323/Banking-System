package com.premchand.banking.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.premchand.banking.exception.BankingException;
import com.premchand.banking.model.Account;
import com.premchand.banking.repository.AccountRepository;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.UncategorizedSQLException;

@ExtendWith(MockitoExtension.class)
class BankingServiceTest {

    @Mock
    private AccountRepository repository;

    @InjectMocks
    private BankingService service;

    private static UncategorizedSQLException oracleError(int code, String msg) {
        return new UncategorizedSQLException("call", "sp", new SQLException("ORA-" + code + ": " + msg, "72000", code));
    }

    @Test
    void getAccount_returnsAccountWhenFound() {
        Account acc = new Account(1L, "Alice", new BigDecimal("100.00"), LocalDateTime.now());
        when(repository.findById(1L)).thenReturn(Optional.of(acc));

        assertEquals("Alice", service.getAccount(1L).holderName());
    }

    @Test
    void getAccount_throwsNotFoundWhenMissing() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        BankingException ex = assertThrows(BankingException.class, () -> service.getAccount(99L));
        assertEquals(HttpStatus.NOT_FOUND, ex.getStatus());
    }

    @Test
    void transfer_callsRepositoryOnSuccess() {
        service.transfer(1L, 2L, new BigDecimal("50"));

        verify(repository).transfer(1L, 2L, new BigDecimal("50"));
    }

    @Test
    void transfer_mapsInsufficientFundsError() {
        doThrow(oracleError(20001, "Insufficient funds"))
                .when(repository).transfer(1L, 2L, new BigDecimal("999999"));

        BankingException ex = assertThrows(BankingException.class,
                () -> service.transfer(1L, 2L, new BigDecimal("999999")));

        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, ex.getStatus());
        assertEquals("Insufficient funds", ex.getMessage());
    }

    @Test
    void withdraw_mapsAccountNotFoundError() {
        doThrow(oracleError(20002, "Account not found"))
                .when(repository).withdraw(5L, new BigDecimal("10"));

        BankingException ex = assertThrows(BankingException.class,
                () -> service.withdraw(5L, new BigDecimal("10")));

        assertEquals(HttpStatus.NOT_FOUND, ex.getStatus());
    }

    @Test
    void transfer_mapsSameAccountError() {
        doThrow(oracleError(20004, "Cannot transfer to the same account"))
                .when(repository).transfer(1L, 1L, new BigDecimal("10"));

        BankingException ex = assertThrows(BankingException.class,
                () -> service.transfer(1L, 1L, new BigDecimal("10")));

        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatus());
    }
}
